import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCConnectDemo {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/mydatabase";
    private static final String USERNAME = "root";
    // Replace with your own MySQL password.
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        String sqlQuery = "SELECT id, username, email FROM users";

        try (Connection connection =
                     DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sqlQuery)) {

            System.out.println("Connected to the database successfully.");

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String username = resultSet.getString("username");
                String email = resultSet.getString("email");

                System.out.println("User ID: " + id
                        + ", Username: " + username
                        + ", Email: " + email);
            }
        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            System.err.println("Check that MySQL is running, the database/table exist, "
                    + "the credentials are correct, and MySQL Connector/J is configured.");
        }
    }
}
