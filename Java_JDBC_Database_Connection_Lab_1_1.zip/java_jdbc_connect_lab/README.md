# JDBC Database Connection — Experiment 1.1

## Aim
Connect to the MySQL database `mydatabase` using JDBC, retrieve records from the `users` table, and print each user's ID, username, and email.

## File
- `JDBCConnectDemo.java`

## Before running
1. Start your MySQL server.
2. Create a database named `mydatabase`.
3. Ensure a table named `users` exists with `id`, `username`, and `email` columns.
4. Open `JDBCConnectDemo.java` and replace `your_password` with your MySQL password.
5. Add MySQL Connector/J to your project's dependencies/classpath.

## Example SQL setup
Run this in MySQL if you need a sample table:

```sql
CREATE DATABASE IF NOT EXISTS mydatabase;
USE mydatabase;

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(200) NOT NULL
);

INSERT INTO users (username, email) VALUES
('johndoe', 'johndoe@example.com'),
('janedoe', 'janedoe@example.com'),
('alice', 'alice@example.com');
```

If the table already contains rows, avoid running the INSERT statements again unless you want duplicate sample data.

## Run
Compile and run after adding the MySQL JDBC driver:

```bash
javac JDBCConnectDemo.java
java -cp ".:/path/to/mysql-connector-j.jar" JDBCConnectDemo
```

Replace `/path/to/mysql-connector-j.jar` with the actual path to the Connector/J JAR. On Windows, use `;` instead of `:` in the classpath.

## Notes
- The URL assumes MySQL is running locally on port `3306`.
- The code uses try-with-resources, so the connection, statement, and result set are closed automatically.
- Do not commit real database passwords to a public GitHub repository.
